package org.test.registration.model;

public class Gender {
	  	public static final String MALE = "M";
	    public static final String FEMALE = "F";

}
