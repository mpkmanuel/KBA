package org.test.registration.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.test.registration.dao.AppUserDAO;
import org.test.registration.formbean.AppUserForm;

@Controller
public class LoginController {
	
	   @Autowired
	   private AppUserDAO appUserDAO;
	
	   // Show Login page.
	   @RequestMapping(value = "/login", method = RequestMethod.GET)
	   public String viewLogin(Model model) {
	      AppUserForm form = new AppUserForm();
	      model.addAttribute("appUserForm", form);
	      return "login.xhtml";
	   }	   
	   
	    @RequestMapping(value = "/login", method = RequestMethod.POST)
	    public String signInlogin(Model model, //
		         @ModelAttribute("appUserForm") @Validated AppUserForm appUserForm, //
		         BindingResult result, //
		         final RedirectAttributes redirectAttributes) {

	    	  boolean ifUserPresent = false;
	      
		      try {
		    	  System.out.println("In Main Controller ");
		          ifUserPresent = appUserDAO.loginAppUser(appUserForm);
		      }
		      // Other error!!
		      catch (Exception e) {
		         model.addAttribute("errorMessage", "Error: " + e.getMessage());
		         return "login.xhtml";
		      }
		 
		      redirectAttributes.addFlashAttribute("flashUser", ifUserPresent);
		      
		      System.out.println(" USer Nameeeeeeeee " + appUserForm.getUserName());
		      redirectAttributes.addFlashAttribute("flashUser", appUserForm.getUserName());
		      String uname =  appUserForm.getUserName();
		      System.out.println("uname " + uname);
		      //return "redirect:/landingPage.html?q=davidb";
		      return "landingPage.xhtml";
		 }
	    
	    @RequestMapping(value = "/logout" , method = RequestMethod.POST)
	    public String logout(Model model, @ModelAttribute("appUserForm") @Validated AppUserForm appUserForm) {
	    	 System.out.println(" Inside Logout Call ");
	    	 appUserDAO.updateLogOut(appUserForm);
	         model.addAttribute("message", "You have been logged out successfully.");
	         appUserForm = new AppUserForm();
	         return "login.xhtml";
	    }		    


}
