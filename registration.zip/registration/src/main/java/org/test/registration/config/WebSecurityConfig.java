package org.test.registration.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.test.registration.dao.AppUserDAO;
import org.test.registration.service.UserDetailsServiceImpl;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.test.registration.model.UserBean;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
 

	@Autowired
	@Qualifier("userDetailsService")
	UserDetailsServiceImpl userDetailsServicesImpl;

	@Autowired
	AppUserDAO appUserDAO;
	
    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsServicesImpl).passwordEncoder(bCryptPasswordEncoder());
    }   	
    
  


    @Bean
    public BCryptPasswordEncoder bCryptPasswordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
    	
    	List<UserBean> getPages = appUserDAO.getPages();
    	
    	for (int i = 0; i < getPages.size(); i++) {
    		http.authorizeRequests().antMatchers(getPages.get(i).getPageName())
    				.hasAnyAuthority(getPages.get(i).getRoleName());
    		System.out.println(" PAgeName = " + getPages.get(i).getPageName());
    		System.out.println(" RoleName = " + getPages.get(i).getRoleName());
    	}  
    	
        /*http
                .authorizeRequests()
                    .antMatchers("/resources/**", "/registration").permitAll()
                    .anyRequest().authenticated()
                    .and()
                .formLogin()
                    .loginPage("/login")
                    .permitAll()
                    .and()
                .logout()
                    .permitAll();*/
					
					
		http.authorizeRequests()
			.antMatchers("login").hasRole("USER")
			.antMatchers("/**").permitAll()
			.and().csrf().disable().headers().frameOptions().disable();					
    }


    
}   
	
