package org.test.registration.model;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.test.registration.Entity.RegistrationEntity;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class ModelBean {
	
	@Bean
	public RegistrationEntity getRegistrationEntityBean() {
		return new RegistrationEntity();
	}	


}
