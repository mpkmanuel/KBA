package org.test.registration.service;


import org.test.registration.Repo.RegistrationRepo;
import org.test.registration.model.AppUser;
import org.test.registration.model.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service("userDetailsService")
public class UserDetailsServiceImpl implements UserDetailsService{
    @Autowired
    private RegistrationRepo userRepository;

    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        AppUser user = userRepository.findByUsername(username);
        
        List<Role> role = userRepository.getRoles();

        Set<GrantedAuthority> grantedAuthorities = new HashSet<>();
        for (Role role1 : role){
            grantedAuthorities.add(new SimpleGrantedAuthority(role1.getName()));
            System.out.println(" Roles "  + role1.getName());
        }
        
        System.out.println(" User Details "  + user.getUserName()  + " ==  pwd = "  +  user.getPassword());

        return new org.springframework.security.core.userdetails.User(user.getUserName(), user.getPassword(), grantedAuthorities);
    }
}
