package org.test.registration.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Users")
public class RegistrationEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UserId")
	private int userId;
	
	@Column(name = "UName")
	private String userName;
	
	@Column(name = "Password")
	private String password;
	
	@Column(name = "Email")
	private String email;
	
	@Column(name = "Gender")
	private String gender;
	
	@Column(name = "FName")
	private String fName;
	
	@Column(name = "LName")
	private String lName;

	@Column(name = "Country")
	private String cCode;
	
	@Column(name = "answer1")
	private String answer1;
	
	@Column(name = "answer2")
	private String answer2;
	
	@Column(name = "answer3")
	private String answer3;
	
	@Column(name = "qid1")	
	private int qid1;
	
	@Column(name = "qid2")
	private int qid2;
	
	@Column(name = "qid3")
	private int qid3;	
	
	@Column(name = "roleid")
	private int roleid;	
	
	@Column(name = "loggedin")
	private String loggedin;
	
	


	public String getLoggedin() {
		return loggedin;
	}

	public void setLoggedin(String loggedin) {
		this.loggedin = loggedin;
	}

	public int getRoleid() {
		return roleid;
	}

	public void setRoleid(int roleid) {
		this.roleid = roleid;
	}

	public int getQid1() {
		return qid1;
	}

	public void setQid1(int qid1) {
		this.qid1 = qid1;
	}

	public int getQid2() {
		return qid2;
	}

	public void setQid2(int qid2) {
		this.qid2 = qid2;
	}

	public int getQid3() {
		return qid3;
	}

	public void setQid3(int qid3) {
		this.qid3 = qid3;
	}


	
	public String getAnswer1() {
		return answer1;
	}

	public void setAnswer1(String answer1) {
		this.answer1 = answer1;
	}

	public String getAnswer2() {
		return answer2;
	}

	public void setAnswer2(String answer2) {
		this.answer2 = answer2;
	}

	public String getAnswer3() {
		return answer3;
	}

	public void setAnswer3(String answer3) {
		this.answer3 = answer3;
	}



	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUName() {
		return userName;
	}

	public void setUName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFName() {
		return fName;
	}

	public void setFName(String fName) {
		this.fName = fName;
	}

	public String getLName() {
		return lName;
	}

	public void setLName(String lName) {
		this.lName = lName;
	}

	public String getCCode() {
		return cCode;
	}

	public void setCCode(String cCode) {
		this.cCode = cCode;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}





}
