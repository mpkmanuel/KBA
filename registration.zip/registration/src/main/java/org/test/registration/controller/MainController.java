package org.test.registration.controller;

import java.util.List;


import org.test.registration.dao.AppUserDAO;
import org.test.registration.dao.CountryDAO;
import org.test.registration.formbean.AppUserForm;
import org.test.registration.model.AppUser;
import org.test.registration.model.Country;
import org.test.registration.validator.AppUserValidator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class MainController {
	 
	   @Autowired
	   private AppUserDAO appUserDAO;
	 
	   @Autowired
	   private CountryDAO countryDAO;
	 
	   @Autowired
	   private AppUserValidator appUserValidator;
	 
	   // Set a form validator
	   @InitBinder
	   protected void initBinder(WebDataBinder dataBinder) {
	      // Form target
	      Object target = dataBinder.getTarget();
	      if (target == null) {
	         return;
	      }
	      System.out.println("Target=" + target);
	 
	      if (target.getClass() == AppUserForm.class) {
	         dataBinder.setValidator(appUserValidator);
	      }
	      // ...
	   }
    
	 
	 /* @RequestMapping(value = "/error")
	    public String error(Model model) {
	        model.addAttribute("message", "You have got errors.");
	        return "welcomePage.xhtml";
	   }  */  
	    
	   @RequestMapping("/")
	   public String viewHome(Model model) {
	 
	      return "welcomePage.xhtml";
	   }
	 
	   @RequestMapping("/members")
	   public String viewMembers(Model model) {
	 
	      List<AppUser> list = appUserDAO.getAppUsers();
	 
	      model.addAttribute("members", list);
	 
	      return "membersPage.xhtml";
	   }
	 

	 

	 

	 	

}
