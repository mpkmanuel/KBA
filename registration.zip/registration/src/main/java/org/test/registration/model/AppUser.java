package org.test.registration.model;

public class AppUser {
	
	 	private int userId;
	    private String userName;
	    private String firstName;
	    private String lastName;
	    private boolean enabled;
	    private String gender;
	    private String email;
	    private String password;
	    private String countryCode;
		private String answer1;
	    private String answer2;
	    private String answer3;
		private int roleid;	 
		private String loggedin;;
	    
		
	 


		public AppUser() {
	 
	    }
	 
	    public AppUser(int userId, String userName, String firstName, String lastName, //
	            boolean enabled, String gender, //
	            String email,String countryCode, String password,String answer1,String answer2, String answer3, int roleid, String loggedin) {
	        super();
	        this.userId = userId;
	        this.userName = userName;
	        this.firstName = firstName;
	        this.lastName = lastName;
	        this.enabled = enabled;
	        this.gender = gender;
	        this.email = email;
	        this.countryCode= countryCode;
	        this.password = password;
	        this.answer1 = answer1;
	        this.answer2 = answer2;
	        this.answer3 = answer3;
	        this.roleid = roleid;
	        this.loggedin = loggedin;
	        
	    }
	    
	    
	 
	    public int getUserId() {
	        return userId;
	    }
	 
	    public void setUserId(int userId) {
	        this.userId = userId;
	    }
	 
	    public String getUserName() {
	        return userName;
	    }
	 
	    public void setUserName(String userName) {
	        this.userName = userName;
	    }
	 
	    public String getFirstName() {
	        return firstName;
	    }
	 
	    public void setFirstName(String firstName) {
	        this.firstName = firstName;
	    }
	 
	    public String getLastName() {
	        return lastName;
	    }
	 
	    public void setLastName(String lastName) {
	        this.lastName = lastName;
	    }
	 
	    public boolean isEnabled() {
	        return enabled;
	    }
	 
	    public void setEnabled(boolean enabled) {
	        this.enabled = enabled;
	    }
	 
	    public String getGender() {
	        return gender;
	    }
	 
	    public void setGender(String gender) {
	        this.gender = gender;
	    }
	 
	    public String getEmail() {
	        return email;
	    }
	 
	    public void setEmail(String email) {
	        this.email = email;
	    }
	 
	    public String getPassword() {
	        return password;
	    }
	 
	    public void setPassword(String Password) {
	        this.password = password;
	    }
	 
	    public String getCountryCode() {
	        return countryCode;
	    }
	 
	    public void setCountryCode(String countryCode) {
	        this.countryCode = countryCode;
	    }
	    
		public String getanswer1() {
			return answer1;
		}

		public void setanswer1(String answer1) {
			this.answer1 = answer1;
		}

		public String getanswer2() {
			return answer2;
		}

		public void setanswer2(String answer2) {
			this.answer2 = answer2;
		}

		public String getanswer3() {
			return answer3;
		}

		public void setanswer3(String answer3) {
			this.answer3 = answer3;
		}

		public int getRoleid() {
			return roleid;
		}

		public void setRoleid(int roleid) {
			this.roleid = roleid;
		}	
		
	    public String getLoggedin() {
			return loggedin;
		}

		public void setLoggedin(String loggedin) {
			this.loggedin = loggedin;
		}		
	 
}


