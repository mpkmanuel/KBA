package org.test.registration.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.test.registration.Entity.RegistrationEntity;
import org.test.registration.Repo.RegistrationRepo;
import org.test.registration.formbean.AppUserForm;
import org.test.registration.model.AppUser;
import org.test.registration.model.Gender;
import org.test.registration.model.UserBean;

@Transactional
@Service
public class AppUserDAO {
	
	@Autowired
	RegistrationRepo registrationRepo;
	
    // Config in WebSecurityConfig
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
    RegistrationEntity registrationEntity;
 
    private static final Map<String, AppUser> USERS_MAP = new HashMap<>();
 
 
    public List<UserBean> getPages() {
		List<UserBean> pageRoleList = new ArrayList<>();
		List<Object[]> pageList = registrationRepo.getPages();
		for (Object[] getPage : pageList) {
			UserBean userBean = new UserBean();
			userBean.setPageName((String) getPage[0]);
			userBean.setRoleName((String) getPage[1]);
			pageRoleList.add(userBean);
		}
		  return pageRoleList;    	
    	
    }
    
    public int getMaxUserId() {
        int max = 0;
        for (String id : USERS_MAP.keySet()) {
            if (Integer.parseInt(id) > max) {
                max = Integer.parseInt(id);
            }
        }
        return max;
    }
 
    //
 
    public AppUser findAppUserByUserName(String userName) {
        Collection<AppUser> appUsers = USERS_MAP.values();
        for (AppUser u : appUsers) {
            if (u.getUserName().equals(userName)) {
                return u;
            }
        }
        return null;
    }
 
    public AppUser findAppUserByEmail(String email) {
        Collection<AppUser> appUsers = USERS_MAP.values();
        for (AppUser u : appUsers) {
            if (u.getEmail().equals(email)) {
                return u;
            }
        }
        return null;
    }
 
    public List<AppUser> getAppUsers() {
        List<AppUser> list = new ArrayList<>();
 
        List<Object[]> appList = registrationRepo.getDetails();
        
        //ArrayList<AppUser> appList1 = registrationRepo.getDetails1();
        
        AppUser appUser = null; 
        
        for (Object[] getApp : appList) {
        	appUser = new AppUser();
        	appUser.setUserId((Integer)getApp[0]);
        	appUser.setUserName((String)getApp[1]);
        	appUser.setPassword((String)getApp[2]);
        	appUser.setEmail((String)getApp[3]);
        	appUser.setFirstName((String)getApp[4]);
        	appUser.setLastName((String)getApp[5]);
        	appUser.setGender((String)getApp[6]);
        	appUser.setCountryCode((String)getApp[7]);
        	list.add(appUser);
        }
        
        
        
        //list.addAll(USERS_MAP.values());
        return list;
        //return appList1;
    
    }
    
    public boolean loginAppUser(AppUserForm form) {
        AppUser user = new AppUser();
        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
        
        String password = form.getPassword();
        user.setUserName(form.getUserName());
        user.setPassword(password);
        //user.setEmail(form.getEmail());
        
        
        boolean flag = false;
        
        String email = registrationRepo.getUserEamil(user.getUserName());
        
        String passwordNew = registrationRepo.getDetails1(user.getUserName(),email);
        
        System.out.println(" User Name = " + user.getUserName());
        System.out.println(" passwordNew = " + passwordNew);
        
        System.out.println(bCryptPasswordEncoder.matches(password, passwordNew));
        
        System.out.println("Boolean === " + flag);
        
        System.out.println("Password === " + password);
        
        if (bCryptPasswordEncoder.matches(password, passwordNew)) {
        	System.out.println("Inside PWD Chech ");
        	registrationRepo.updateDetailsLogin(user.getUserName());
        	System.out.println("After PWD Chech " );
        	flag = true;
        }
        return flag;

    }    
 
    //public AppUser forgotPassword(AppUserForm form) {
    public String forgotPassword(AppUserForm form) {    	
    	
        AppUser user = new AppUser();

        user.setUserName(form.getUserName());
        user.setanswer1(form.getQuestion1());
        user.setanswer2(form.getQuestion2());
        user.setanswer3(form.getQuestion3());
        user.setEmail(form.getEmail());
        
        String userName = user.getUserName();
        String email = user.getEmail();
        String ans1 = null;
        ans1 = user.getanswer1();
        String ans2 = null;
        ans2 = user.getanswer2();
        String ans3 = null;
        ans3 = user.getanswer3();
        
        
        System.out.println("In DAO before Forgot PWD ");
        
        /*String[] getApp = registrationRepo.forgotPassword(userName,ans1,ans2,ans3);
        
        	AppUser appUser = null; 
        	appUser = new AppUser();
        	appUser.setEmail((String)getApp[0]);
        	appUser.setPassword((String)getApp[1]);*/
        
        
        String emailNew = registrationRepo.forgotPassword(userName,ans1,ans2,ans3);
        
        System.out.println("Email = " + emailNew);
        //System.out.println("Password = " + appUser.getPassword());
        
        System.out.println("In DAO after Forgot PWD ");
        
        //return appUser;	
        return emailNew;
    }
    

    public void resetPassword(AppUserForm form) {
        AppUser user = new AppUser();
        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
        String password = null;
        if (form.getPassword().equals(form.getNewpassword())) { 
        	password = bCryptPasswordEncoder.encode(form.getNewpassword());
        } 
        user.setUserName(form.getUserName());
        String userName = user.getUserName();
        registrationRepo.resetPassword(userName,password);
    }
  
    
    public AppUser createAppUser(AppUserForm form) {
        int userId = this.getMaxUserId() + 1;
        
        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
        
        String password = bCryptPasswordEncoder.encode(form.getPassword());
 
        AppUser user = new AppUser(userId, form.getUserName(), form.getFirstName(), form.getLastName(), 
        			false, form.getGender(), form.getEmail(), form.getCountryCode(), password,form.getQuestion1(),form.getQuestion2(),form.getQuestion3(),form.getRoleid(),"N");
        
        
        //if (null == userId) {
        	//registrationEntity.setUserId(userId);
	        registrationEntity.setCCode(form.getCountryCode());
	        registrationEntity.setEmail(form.getEmail());
	        registrationEntity.setFName(form.getFirstName());
	        registrationEntity.setLName(form.getLastName());
	        registrationEntity.setUName(form.getUserName());
	        registrationEntity.setPassword(password);
	        registrationEntity.setGender(form.getGender());
	        registrationEntity.setQid1(1);
	        registrationEntity.setAnswer1(form.getQuestion1());
	        registrationEntity.setQid2(2);
	        registrationEntity.setAnswer2(form.getQuestion2());
	        registrationEntity.setQid3(3);
	        registrationEntity.setAnswer3(form.getQuestion3());
	        registrationEntity.setRoleid(form.getRoleid());
	        registrationEntity.setLoggedin("N");
	        registrationRepo.save(registrationEntity);
	        
	        System.out.println(" After save to Repo");
        //}
        
        //USERS_MAP.put(userId, user);
        return user;
    }	
    
    
    public void updateLogOut(AppUserForm appUserForm) {
    	 
    	System.out.println(" UserName = " + appUserForm.getUserName());
    	String uname = appUserForm.getUserName();
    	registrationRepo.updateLogOut(uname);
    	
    }

}
