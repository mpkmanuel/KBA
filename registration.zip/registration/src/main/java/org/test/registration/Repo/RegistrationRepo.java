package org.test.registration.Repo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.test.registration.Entity.RegistrationEntity;
import org.test.registration.model.AppUser;
import org.test.registration.model.Role;;


@Repository
@Transactional
public interface RegistrationRepo extends CrudRepository<RegistrationEntity, Integer>{
	
	
	@Query(value="SELECT UserId , UName ,Password,Email,FName,LName,Gender,Country FROM users ",nativeQuery=true)
	List<Object[]> getDetails();
	
	@Query(value="SELECT Password FROM users where UName=:username and Email=:email ",nativeQuery=true)
	String getDetails1(String username, String email);
	
	@Query(value="SELECT Email FROM users where UName=:username  ",nativeQuery=true)
	String getUserEamil(String username);	
	
	@Query(value="SELECT  UName ,Password, Email, FName, LName, Gender, Country FROM users where UName=:username ",nativeQuery=true)
	AppUser findByUsername(String username);
	
	@Query(value="SELECT ROLENAME from ROLES ",nativeQuery=true)
	List<Role> getRoles();
	
	@Modifying
	@Query(value="update users set loggedin='N' where UName=:username ",nativeQuery=true)
	void updateLogOut(String username);
	
	@Modifying
	@Query(value="update users set loggedin='Y' where UName=:username ",nativeQuery=true)
	void updateDetailsLogin(String username);	

	@Query(value="select Email from users where UName=:username and (answer1=:ans1 or answer2=:ans2 or answer3=:ans3) ",nativeQuery=true)
	String forgotPassword(String username, String ans1, String ans2, String ans3);

	@Modifying
	@Query(value="update users set Password=:password where UName=:username ",nativeQuery=true)
	void resetPassword(String username,String password);	
	
	@Query(value = "select pageName, ROLENAME from pages, roles where pages.userRole = roles.ROLEID order by pageName", nativeQuery = true)
	List<Object[]> getPages() throws DataAccessException;	
	

 }
